let username = ' Ivaylo ';

let trimmedUsername = username.trim();

console.log(trimmedUsername);

console.log(username.trimStart());
console.log(username.trimEnd());