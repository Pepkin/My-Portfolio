let text = 'Lorem ipsum dolor sit amet consectetur, adipisicing elit. Harum officiis est accusamus. Dolore beatae perspiciatis, tenetur laborum magnam officia quibusdam.';

// split
let sentences = text.split('. ');
console.log(sentences);

// includes
let hasDolor = text.includes('dolor');
console.log(hasDolor);