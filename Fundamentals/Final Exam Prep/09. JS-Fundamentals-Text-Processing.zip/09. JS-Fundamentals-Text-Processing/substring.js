let text = 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Velit aperiam a dolor at asperiores, optio voluptatem id delectus incidunt esse sed!dolor'

let secondWord = text.substring(7, 12);
console.log(secondWord);