let text = 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Repudiandae, necessitatibus?';

let startsWithLorem = text.startsWith('Lorem');
let endsWithNeshtoSi = text.endsWith('?');

console.log(startsWithLorem);
console.log(endsWithNeshtoSi);
