let bits = ['101', '11', '100000', '1010011', '11111111'];

for (const bit of bits) {
    console.log(bit.padStart(8, '0'));
}