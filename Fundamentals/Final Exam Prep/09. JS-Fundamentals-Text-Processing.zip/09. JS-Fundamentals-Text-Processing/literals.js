let dobleQuoted = "Hello";

let singleQuoted = 'World';

let quote = 'He said: "hello world"';
let seconQuote = "K'vo staa";

let escapeCharacter = 'K\'vo staa';

let multilineTemplateLiteral = `
    first line
    second line
    las line
`;

let templateLiteral = `${dobleQuoted} ${singleQuoted}!`;

console.log(multilineTemplateLiteral);

let concatenatedString = dobleQuoted + ' ' + singleQuoted;
let sum = 10 + 10;
let asdf = 10 + '10';