function substring(text, index, count) {
    let result = text.substring(index, index + count);
    console.log(result);
}

substring('ASentence', 1, 8);